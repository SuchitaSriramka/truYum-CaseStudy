function validationMsg(){
	var title = document.getElementById("title").value;
	var price = document.getElementById("price").value;
	var date = document.getElementById("dateOfLaunch").value;
	var category = document.getElementById("category");
	var catType = category.options[category.selectedIndex].value;
	var titleLen = title.length;
	if(title == "") {
		alert("Title is required.");
		return false;
	} else if(titleLen < 2 || titleLen > 65) {
		alert("Title should have 2 to 65 characters.");
		return false;
	}
	if(price == ""){
		alert("Price is required");
		return false;
	} else if(isNaN(price)){
		alert("Price has to be a number");
		return false;
	}
	if(date ==  ""){
		alert("Date of Launch is required");
		return false;
	}
	if(catType == "Select"){
		alert("Select one category");
		return false;
	}
	window.location.assign("edit-menu-item-status.html");
	return false;
}